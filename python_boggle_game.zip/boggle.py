import GUI
from ex12_utils import *


def words_dictionary():
    """ this function turns given boggle_dict text file which contains all possible words in game into an
     iterable dictionary sorted by length of word. values in dictionary are lists of strings"""
    words_list = []
    boggle_dict = open("boggle_dict.txt", "r")
    for word in boggle_dict:
        words_list.append(word.rstrip("\n"))
    return words_list


class Controller:
    def __init__(self) -> None:
        self._gui = GUI.BoggleGUI()

    @staticmethod
    def is_word_in_dict(board, path):
        """ this function checks if word is in dictionary"""
        if is_valid_path(board, path, words_dictionary()):
            return True
        else:
            return False

    @staticmethod
    def is_letter_around_key(coord):
        """this function checks letters that are around chosen key=button"""
        return get_coords_around_word_cell(coord)

    @staticmethod
    def update_score(path):
        """ this function updates score according to rules of the game"""
        return len(path)**2


def main():
    board = GUI.BoggleGUI()
    board.run()


if __name__ == "__main__":
    main()
