import collections
import copy
import itertools

import boggle_board_randomizer

HEIGHT = 4
WIDTH = 4


def cell_list(HEIGHT, WIDTH):
    """

    :param HEIGHT: constant
    :param WIDTH: constant
    :return: coordinates of cells in this board.

    """
    cell_lst = []
    for i in range(HEIGHT):
        for j in range(WIDTH):
            cell_lst.append((i, j))
    return cell_lst


def get_coords_around_word_cell(cell_coord):
    """

    :param cell_coord: list of coord tuples
    :return: list of the coordinates around a certain cell

    """
    coords_frame = []
    diagonal_list = []
    cell_lst = cell_list(HEIGHT, WIDTH)
    for board_cell in cell_lst:
        radius = abs(cell_coord[0] - board_cell[0]) + abs(cell_coord[1] - board_cell[1])
        if radius == 1:
            coords_frame.append(board_cell)
    diagonal_left_up = (cell_coord[0] - 1, cell_coord[1] - 1)
    diagonal_left_down = (cell_coord[0] - 1, cell_coord[1] + 1)
    diagonal_right_up = (cell_coord[0] + 1, cell_coord[1] - 1)
    diagonal_right_down = (cell_coord[0] + 1, cell_coord[1] + 1)
    diagonal_list.append(diagonal_left_up)
    diagonal_list.append(diagonal_left_down)
    diagonal_list.append(diagonal_right_up)
    diagonal_list.append(diagonal_right_down)
    for coord in diagonal_list:
        if coord in cell_lst:
            coords_frame.append(coord)
    return coords_frame


def is_valid_path(board, path, words):
    """
    checks if a path is legal and if it creates a word from the dictionary
    :param board: list of lists
    :param path: list of tuples
    :param words: dictionary. keys are length of word and values are words.
    :return: bool
    """
    old_coordinate = 0
    if path == []:
        return None
    first_tuple_row = path[0][0]
    first_tuple_col = path[0][1]
    cell_lst = cell_list(HEIGHT, WIDTH)
    if path[0] not in cell_lst:
        return None
    word_list = [board[first_tuple_row][first_tuple_col]]
    for word_cell in path:
        if word_cell not in cell_lst:
            return None
        if path.count(word_cell) > 1:
            return None
        else:
            if word_cell != path[0]:
                coords_around_old_word_cell = get_coords_around_word_cell(old_coordinate)
                if word_cell in coords_around_old_word_cell:
                    word_row = word_cell[0]
                    word_col = word_cell[1]
                    word_list += (board[word_row][word_col])
            old_coordinate = word_cell
    for word in words:
        if word == ''.join(word_list):
            return word
        else:
            continue


def get_word_from_coords(board, coords_list):
    """

    :param board: list of lists
    :param coords_list: coords of a word
    :return: string of the word
    """
    word_list = []
    for tpl in coords_list:
        tpl_row = tpl[0]
        tpl_col = tpl[1]
        word_list.append(board[tpl_row][tpl_col])
    return ''.join(word_list)


def get_list_of_n_length_words(words, n):
    """

    :param words: iterable
    :param n: length of word
    :return: list of n length words
    """
    word_list = []
    for word in words:
        if len(word) == n:
            word_list.append(word)
    return word_list


def helper_find_length_n_paths(n, all_paths, board, words, coord, path):
    """

    :param n: length of path
    :param all_paths: list of good paths
    :param board: list
    :param words: iterable
    :param coord: tuple
    :param path: specific path
    :return: all paths to find_length_n_paths
    """
    if len(path) == n:
        the_word = get_word_from_coords(board, path)
        words_same_length_as_word = get_list_of_n_length_words(words, len(the_word))
        for word in words_same_length_as_word:
            if word == the_word:
                all_paths.append(copy.deepcopy(path))
                return
        return
    for tpl in get_coords_around_word_cell(coord):
        if tpl not in path:
            path.append(tpl)
            for word in words:
                if get_word_from_coords(board, path) not in word:
                    continue
                else:
                    helper_find_length_n_paths(n, all_paths, board, words, tpl, path)
            path.pop()


def find_length_n_paths(n, board, words):
    """

    :param n: length of path
    :param board: list
    :param words: iterable
    :return: all paths

    """
    all_paths = []
    final_list = []
    cell_lst = cell_list(HEIGHT, WIDTH)
    for coord in cell_lst:
        path = [coord]
        helper_find_length_n_paths(n, all_paths, board, words, coord, path)
    for lst in all_paths:
        if lst not in final_list:
            final_list.append(lst)
    return final_list


def helper_find_length_n_words(n, all_paths, board, words, coord, path):
    """

    :param n: length of word
    :param all_paths: list of good paths
    :param board: list
    :param words: iterable
    :param coord: tuple
    :param path: specific path
    :return: all paths to find_length_n_words

    """
    if len(get_word_from_coords(board, path)) == n:
        for word in get_list_of_n_length_words(words, n):
            if word == get_word_from_coords(board, path):
                all_paths.append(copy.deepcopy(path))
                return
        return
    for tpl in get_coords_around_word_cell(coord):
        if tpl not in path:
            path.append(tpl)
            for word in words:
                if get_word_from_coords(board, path) not in word:
                    continue
                else:
                    helper_find_length_n_words(n, all_paths, board, words, tpl, path)
            path.pop()


def find_length_n_words(n, board, words):
    """

    :param n: length of word
    :param board: list
    :param words: iterable
    :return: all paths

    """
    all_paths = []
    final_list = []
    cell_lst = cell_list(HEIGHT, WIDTH)
    for coord in cell_lst:
        path = [coord]
        helper_find_length_n_words(n, all_paths, board, words, coord, path)
    for lst in all_paths:
        if lst not in final_list:
            final_list.append(lst)
    return final_list


def max_score_paths(board, words):
    """

    :param board:
    :param words:
    :return:

    """
    max_score_list_all_paths = []
    max_score_list_all_words = []

    for i in range(16, 0, -1):
        length_n_paths = find_length_n_paths(i, board, words)
        for path1 in length_n_paths:
            if get_word_from_coords(board, path1) in words and get_word_from_coords(board, path1) not in max_score_list_all_words:
                max_score_list_all_words.append(get_word_from_coords(board, path1))
                max_score_list_all_paths.append(path1)
            else:
                continue
    return max_score_list_all_paths
