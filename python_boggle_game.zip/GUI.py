import tkinter as tki
from typing import Callable, Dict, List, Any
import boggle_board_randomizer
import ex12_utils
from boggle import *
from ex12_utils import *

HEIGHT = 4
WIDTH = 4
BOARD = boggle_board_randomizer.randomize_board()
BUTTON_HOVER_COLOR = 'blue'
REGULAR_COLOR = 'lightblue'
BUTTON_ACTIVE_COLOR = 'purple'
LABEL_COLOR = 'white'

BUTTON_STYLE = {"font": ("Courier", 30),
                "borderwidth": 1,
                "relief": tki.RAISED,
                "bg": REGULAR_COLOR,
                "activebackground": BUTTON_ACTIVE_COLOR}


class BoggleGUI:
    _buttons: Dict[str, tki.Button] = {}

    def __init__(self) -> None:
        root = tki.Tk()
        root.resizable(False, False)
        self._main_window = root
        self._score = 0
        self._current_word = ""
        self._word_list = []
        self._dict = {}
        self.create_dictionary(BOARD)
        self._outer_frame = tki.Frame(root, bg=REGULAR_COLOR,
                                      highlightbackground=REGULAR_COLOR,
                                      highlightthickness=5)
        self._outer_frame.pack(side=tki.TOP, fill=tki.BOTH, expand=True)
        self._display_label = tki.Label(self._outer_frame, font=("Helvetica", 30),
                                        bg=REGULAR_COLOR, width=25, relief="ridge", text="Boggle Game")
        self._display_label.pack(side=tki.TOP, fill=tki.BOTH)

        self._lower_frame = tki.Frame(self._outer_frame)
        self._lower_frame.pack(side=tki.TOP, fill=tki.BOTH, expand=True)
        self._seconds = 180
        self._timer_label = tki.Label(self._outer_frame, font=("Helvetica", 15), bg=LABEL_COLOR, width=20,
                                      height=10, relief="ridge", text=f"{self._seconds // 60}:{self._seconds % 60}")
        self._timer_label.pack(padx=5, pady=15, side=tki.LEFT)
        self.update()
        self._score_label = tki.Label(self._outer_frame, font=("Helvetica", 15), bg=LABEL_COLOR, width=20, height=10,
                                      relief="ridge", text="score")
        self._score_label.pack(padx=5, pady=15, side=tki.RIGHT)
        self._word_bank_label = tki.Label(self._outer_frame, font=("Helvetica", 15), bg=LABEL_COLOR, width=50,
                                          height=4, relief="ridge", text="word bank")
        self._word_bank_label.pack(padx=5, pady=15, side=tki.BOTTOM)
        self._word_chosen = tki.Label(self._outer_frame, font=("Helvetica", 15), bg=LABEL_COLOR, width=50,
                                          height=4, relief="ridge", text="current word:")
        self._word_chosen.pack(padx=5, pady=15, side=tki.BOTTOM)
        self._path = []

        self._create_buttons_in_board()

        self._main_window.bind("<Key>", self._key_pressed)

    def get_button_chars(self) -> List[str]:
        """ this function returns a list of all the keys"""
        return list(self._buttons.keys())

    def update(self) -> None:
        """ this function updates timer every second"""
        if self._seconds == 0:
            self._main_window.destroy()
        else:
            self._seconds -= 1
            seconds = self._seconds % 60
            s1 = seconds // 10
            s2 = seconds % 10
            self._timer_label['text'] = f"{self._seconds // 60}:{s1}{s2}"
            self._main_window.after(1000, self.update)

    def run(self) -> None:
        """ this function runs root"""
        self._main_window.mainloop()

    def set_display(self, display_text: str) -> None:
        """ this function updates text of display text"""
        self._display_label["text"] = display_text

    def set_button_command(self, button_name: str, cmd: Callable[[], None]) -> None:
        self._buttons[button_name].configure(command=cmd)

    def _create_buttons_in_board(self) -> None:
        """ this function places different letters and submit widget on board"""
        for i in range(4):
            tki.Grid.columnconfigure(self._lower_frame, i, weight=1)  # type: ignore
        for row in range(4):
            for column in range(4):
                self._make_button(BOARD[row][column], row, column)
        self._make_button("SUBMIT", 4, 0, column_span=4)

    def create_dictionary(self, BOARD) -> None:
        cell_list = ex12_utils.cell_list(len(BOARD), len(BOARD[0]))
        letters_list = []
        for row in BOARD:
            for letter in row:
                letters_list.append(letter)
        for i in range(len(cell_list)):
            self._dict[cell_list[i]] = letters_list[i]

    def create_word(self, letter, row, col) -> None:
        """ this function creates words from letters in board and adds it to word bank"""
        if letter != "SUBMIT":
            if not self._path:
                self._path.append((row, col))
                self._current_word += letter
                self._word_chosen['text'] = str(self._current_word)
            else:
                if (row, col) in Controller.is_letter_around_key(self._path[-1]):
                    self._current_word += letter
                    self._word_chosen['text'] = str(self._current_word)
                    self._path.append((row, col))
                    print(self._current_word)
        if letter == "SUBMIT":
            if Controller.is_word_in_dict(BOARD, self._path):
                if self._current_word not in self._word_list:
                    self._score += Controller.update_score(self._current_word)
                    self._word_list.append(self._current_word)
                    self._word_bank_label['text'] = str(self._word_list)
                    self._score_label['text'] = str(self._score)
                    self._current_word = ""
                    self._path = []
                else:
                    self._current_word = ""
                    self._path = []
            else:
                self._current_word = ""
                self._path = []

    def _make_button(self, button_char: str, row: int, col: int,
                     row_span: int = 1, column_span: int = 1) -> None:
        """ this function places buttons in board"""
        button = tki.Button(self._lower_frame, text=button_char, command=lambda: self.create_word(button_char, row, col),
                            **BUTTON_STYLE)
        button.grid(row=row, column=col, rowspan=row_span, columnspan=column_span, sticky=tki.NSEW)
        self._buttons[button_char] = button

    def _key_pressed(self, event: Any) -> None:
        """this is a callback method for when a key is pressed.
        It'll simulate a button press on the right button which represents a letter."""
        if event.letter in self._buttons:
            self._simulate_button_press(event.letter)

    def _simulate_button_press(self, button_char: str) -> None:
        """ this function makes button change color if pressed """
        button = self._buttons[button_char]
        button["bg"] = BUTTON_ACTIVE_COLOR

