import hangman_helper


def update_word_pattern(word, pattern, letter):
    """this function updates the pattern"""
    list_of_word = list(word)
    list_of_pattern = list(pattern)
    for i in range(0, len(word)):
        if word[i] == letter:
            list_of_pattern[i] = list_of_word[i]
    return "".join(list_of_pattern)


def run_single_game(words_list, score):
    """this function defines one game"""
    word = hangman_helper.get_random_word(words_list)
    wrong_guess_lst = []
    pattern = len(word)*"_"
    msg = "let's start!"
    while "_" in pattern and score != 0:
        hangman_helper.display_state(pattern, wrong_guess_lst, score, msg)
        msg = "good job, you got some right. keep going"
        magic, choice = hangman_helper.get_input()
        if magic == hangman_helper.LETTER:
            if len(choice) > 1 or not choice.isalpha() or choice.isupper():
                msg = "invalid input"
            elif choice in wrong_guess_lst or choice in pattern:
                msg = "letter was already chosen"
            else:
                score -= 1
                if choice in word:
                    pattern = update_word_pattern(word, pattern, choice)
                    n = word.count(choice)
                    score += (n*(n+1)//2)
                else:
                    wrong_guess_lst.append(choice)
                    msg = "this letter is not in the word"
        elif magic == hangman_helper.WORD:
            score -= 1
            if choice == word:
                counter = 0
                for i in pattern:
                    if i == "_":
                        counter += 1
                pattern = word
                k = counter
                score += (k*(k+1)//2)
        elif magic == hangman_helper.HINT:
            score -= 1
            clues = filter_words_list(words_list, pattern, wrong_guess_lst)
            hint_length = hangman_helper.HINT_LENGTH
            n = len(clues)
            few_clues = []
            if len(clues) > hangman_helper.HINT_LENGTH:
                for i in range(0, hint_length):
                    few_clues.append(clues[i*n // hint_length])
                hangman_helper.show_suggestions(few_clues)
            if len(clues) <= hangman_helper.HINT_LENGTH:
                hangman_helper.show_suggestions(clues)
            msg = "Hope the clue helped"

    if "_" not in pattern:
        msg = "you won!"
        hangman_helper.display_state(pattern, wrong_guess_lst, score, msg)
    else:
        msg = f"you lost! the word was {word}"
        hangman_helper.display_state(pattern, wrong_guess_lst, score, msg)
    return score


def filter_words_list(words, pattern, wrong_guess_lst):
    """this function returns the optional clues"""
    right_list = []
    for word in words:
        good_clue = True
        if len(word) == len(pattern):
            for i in range(len(word)):
                if word[i] in wrong_guess_lst:
                    good_clue = False
                if pattern[i] != "_" and pattern[i] != word[i]:
                    good_clue = False
                if pattern[i] != "_" and word.count(word[i]) != pattern.count(word[i]):
                    good_clue = False
            if good_clue:
                right_list.append(word)
    return right_list


def main():
    """this function is a run of multiple games"""
    words_list = hangman_helper.load_words()
    total_score = hangman_helper.POINTS_INITIAL
    round_score = run_single_game(words_list, total_score)
    again = True
    games_played = 0
    while again:
        if round_score > 0:
            games_played += 1
            total_score = round_score
            msg_win = f"games played: {games_played}\nscore:{total_score}\nplay another round?"
            again = hangman_helper.play_again(msg_win)
            if again:
                round_score = run_single_game(words_list, total_score)
                continue
        elif round_score == 0:
            games_played += 1
            msg_lose = f"games played: {games_played}\nscore:{0}\nstart new game?"
            again = hangman_helper.play_again(msg_lose)
            if again:
                games_played = 0
                round_score = run_single_game(words_list, total_score)
                continue

if __name__ == '__main__':
    main()