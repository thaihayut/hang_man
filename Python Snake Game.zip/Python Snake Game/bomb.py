import game_parameters
from game_parameters import *


def cell_list(cols, rows) -> list[tuple]:
    """
    This function returns the coordinates of cells in this board.
    """
    cell_lst = []
    for i in range(cols):
        for j in range(rows):
            cell_lst.append((i, j))
    return cell_lst


class Bomb:
    """
    Class Bomb
    """
    def __init__(self) -> None:
        """builds new bomb object"""
        bomb_data = get_random_bomb_data()
        """self.bomb_location returns row, col, radius, time"""
        col = bomb_data[0]
        row = bomb_data[1]
        max_radius = bomb_data[2]
        time = bomb_data[3]
        self.__bomb_location = (col, row)
        self.__max_radius = max_radius
        self.__radius = 0
        self.__explosion_time = time
        self.__countdown_after_explosion = 0

    def get_bomb_location(self) -> tuple:
        return self.__bomb_location

    def get_radius(self) -> int:
        return self.__radius

    def get_max_radius(self) -> int:
        return self.__max_radius

    def get_explosion_time(self) -> int:
        return self.__explosion_time

    def countdown_to_explosion(self) -> int:
        if self.__explosion_time > 0:
            self.__explosion_time -= 1
        return self.__explosion_time

    def did_bomb_explode(self) -> bool:
        if self.__explosion_time == 0:
            return True
        else:
            return False

    def countdown_after_explosion(self) -> None:
        self.__countdown_after_explosion += 1

    def get_progress_radius(self) -> int:
        if self.__radius <= self.__max_radius:
            self.__radius += 1
        return self.__radius

    def coordinates_of_wave(self) -> list[tuple]:
        true_colored_cells = []
        for colored_cell in cell_list(game_parameters.WIDTH, game_parameters.HEIGHT):
            """check which tuple fits with equation"""
            cell_row = colored_cell[1]
            cell_col = colored_cell[0]
            bomb_row = self.__bomb_location[1]
            bomb_col = self.__bomb_location[0]
            radius = abs(bomb_row - cell_row) + abs(bomb_col - cell_col)
            if radius == self.__radius:
                true_colored_cells.append((cell_col, cell_row))
        return true_colored_cells

