import typing
from game_parameters import *


class Apples:
    def __init__(self) -> None:
        apple_data = get_random_apple_data()
        row = apple_data[0]
        col = apple_data[1]
        self.__score = apple_data[2]
        self.__location = (row, col)

    def get_score(self) -> int:
        return self.__score

    def get_location(self) -> tuple:
        return self.__location

    def get_row(self) -> int:
        return self.__location[0]

    def get_col(self) -> int:
        return self.__location[1]


