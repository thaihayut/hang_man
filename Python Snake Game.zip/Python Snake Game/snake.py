from game_parameters import *


class Snake:
    """
    Class Snake
    """

    def __init__(self, head_row, head_col) -> None:
        """builds new snake object"""
        self.__head = (head_col, head_row)
        self.__old_head_direction = "Up"
        self.__new_head_direction = "Up"
        self.__coordinates = [(head_col, head_row), (head_col, head_row - 1), (head_col, head_row - 2)]

    def get_snake_head(self) -> tuple:
        return self.__head

    def set_head_direction(self, movekey) -> None:
        self.__old_head_direction = self.__new_head_direction
        self.__new_head_direction = movekey

    def get_snake_coordinates(self) -> list[tuple]:
        return self.__coordinates

    def return_destination_coordinate(self, movekey) -> tuple:
        """this function will be used to know if there is an apple\bomb in the destination coordinate"""
        if self.__new_head_direction == 'Right':
            if self.__old_head_direction != 'Left':
                new_head_row = self.__head[1]
                new_head_col = self.__head[0] + 1
                destination_coordinate = (new_head_col, new_head_row)
                return destination_coordinate
            self.__new_head_direction = 'Left'
        if self.__new_head_direction == 'Left':
            if self.__old_head_direction != 'Right':
                new_head_row = self.__head[1]
                new_head_col = self.__head[0] - 1
                destination_coordinate = (new_head_col, new_head_row)
                return destination_coordinate
            self.__new_head_direction = 'Right'
            new_head_row = self.__head[1]
            new_head_col = self.__head[0] + 1
            destination_coordinate = (new_head_col, new_head_row)
            return destination_coordinate
        if self.__new_head_direction == 'Up':
            if self.__old_head_direction != 'Down':
                new_head_row = self.__head[1] + 1
                new_head_col = self.__head[0]
                destination_coordinate = (new_head_col, new_head_row)
                return destination_coordinate
            self.__new_head_direction = 'Down'
        if self.__new_head_direction == 'Down':
            if self.__old_head_direction != 'Up':
                new_head_row = self.__head[1] - 1
                new_head_col = self.__head[0]
                destination_coordinate = (new_head_col, new_head_row)
                return destination_coordinate
            self.__new_head_direction = 'Up'
            new_head_row = self.__head[1] + 1
            new_head_col = self.__head[0]
            destination_coordinate = (new_head_col, new_head_row)
            return destination_coordinate

    def is_destination_coordinate_legal(self, movekey) -> bool:
        destination_coordinate = self.return_destination_coordinate(movekey)
        if destination_coordinate[0] < -1 or destination_coordinate[0] >= WIDTH + 1:
            return False
        if destination_coordinate[1] < -1 or destination_coordinate[1] >= HEIGHT + 1:
            return False
        else:
            return True

    def move_to_destination_coordinate(self, movekey) -> None:
        destination_coordinate = self.return_destination_coordinate(movekey)
        self.__head = destination_coordinate
        self.__coordinates.insert(0, self.__head)
        self.__coordinates.pop()

    def snake_ate_apple(self, movekey) -> None:
        destination_coordinate = self.return_destination_coordinate(movekey)
        self.__head = destination_coordinate
        self.__coordinates.insert(0, self.__head)
