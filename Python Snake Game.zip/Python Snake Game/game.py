from bomb import Bomb
from apples import Apples
from snake import Snake


class Game:
    def __init__(self) -> None:
        self.__score = 0
        self.__snake = Snake(10, 10)
        self.__bomb = Bomb()
        self.__apple_1 = Apples()
        self.__apple_2 = Apples()
        self.__apple_3 = Apples()
        self.__apple_list = [self.__apple_1, self.__apple_2, self.__apple_3]
        self.__ate_apple_counter = 0

    def get_bomb(self):
        return self.__bomb

    def change_bomb(self, bomb):
        self.__bomb = bomb

    def get_apple_1(self):
        return self.__apple_1

    def get_apple_2(self):
        return self.__apple_2

    def get_apple_3(self):
        return self.__apple_3

    def get_apple_list(self):
        return self.__apple_list

    def get_score(self):
        return self.__score

    def add_to_score(self, num):
        self.__score += num

    def get_snake(self):
        return self.__snake

    def get_counter(self):
        return self.__ate_apple_counter

    def add_to_counter(self, num):
        self.__ate_apple_counter += num

    def body_and_head_collision(self, gd, snake_without_head, coordinates_snake, coordinates_wave):
        if bool(set(snake_without_head) & {self.__snake.get_snake_head()}):
            """checks for bad placing between head and snake body"""
            for tpl in coordinates_snake:
                gd.draw_cell(tpl[0], tpl[1], "black")
            if self.__bomb.did_bomb_explode():
                for wave in coordinates_wave:
                    row_wave = wave[1]
                    col_wave = wave[0]
                    gd.draw_cell(col_wave, row_wave, "orange")
            else:
                gd.draw_cell(self.__bomb.get_bomb_location()[0], self.__bomb.get_bomb_location()[1], "red")
            for i in range(len(self.__apple_list)):
                location = self.__apple_list[i].get_location()
                gd.draw_cell(location[0], location[1], "green")
            return True

    def wave_snake_collision(self, gd, coords_of_snake, coords_of_wave, apple_lst):
        if self.__bomb.did_bomb_explode():
            for tpl in coords_of_snake:
                gd.draw_cell(tpl[0], tpl[1], "black")
            for wave in coords_of_wave:
                row_wave = wave[1]
                col_wave = wave[0]
                gd.draw_cell(col_wave, row_wave, "orange")
            for wave in (set(coords_of_wave) & set(coords_of_snake)):
                row_wave = wave[1]
                col_wave = wave[0]
                gd.draw_cell(col_wave, row_wave, "orange")
        if not self.__bomb.did_bomb_explode():
            for tpl in coords_of_snake[1:]:
                gd.draw_cell(tpl[0], tpl[1], "black")
            gd.draw_cell(self.__bomb.get_bomb_location()[0], self.__bomb.get_bomb_location()[1], "red")
        for i in range(len(apple_lst)):
            location = apple_lst[i].get_location()
            gd.draw_cell(location[0], location[1], "green")

    def move_snake(self, gd, key_clicked):
        for tpl in self.__snake.get_snake_coordinates():
            gd.draw_cell(tpl[0], tpl[1], "black")
        if self.__ate_apple_counter > 0:
            self.__snake.snake_ate_apple(movekey=key_clicked)
            self.__ate_apple_counter -= 1
        else:
            self.__snake.move_to_destination_coordinate(key_clicked)
