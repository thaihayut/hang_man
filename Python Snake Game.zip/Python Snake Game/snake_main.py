import game_parameters
from apples import Apples
from bomb import Bomb
from bomb import cell_list
import game_display
from game import Game


def main_loop(gd: game_display.GameDisplay) -> None:
    game = Game()
    while True:
        coordinates_of_bomb = [game.get_bomb().get_bomb_location()]
        apple_list_locations = [game.get_apple_1().get_location(), game.get_apple_2().get_location(),
                                game.get_apple_3().get_location()]
        coordinates_of_wave = game.get_bomb().coordinates_of_wave()
        coordinates_of_snake = game.get_snake().get_snake_coordinates()
        coordinates_of_snake_without_head = game.get_snake().get_snake_coordinates()[1:]
        matching_coords_bomb_snake_body = bool(set(coordinates_of_bomb) & set(coordinates_of_snake_without_head))
        all_occupied_cells = coordinates_of_snake + coordinates_of_wave + apple_list_locations + coordinates_of_bomb
        matching_coords_wave_snake = bool(set(coordinates_of_wave) & set(coordinates_of_snake))
        """bad placing"""
        if game.body_and_head_collision(gd, coordinates_of_snake_without_head, coordinates_of_snake, coordinates_of_wave):
            gd.end_round()
            break
        if matching_coords_bomb_snake_body:
            """checks for bad first placing between bomb and snake"""
            game.change_bomb(Bomb())

        if matching_coords_wave_snake:
            game.wave_snake_collision(gd, coordinates_of_snake, coordinates_of_wave, game.get_apple_list())
            gd.end_round()
            break
        if len(all_occupied_cells) == game_parameters.WIDTH * game_parameters.HEIGHT:
            """checks for bad placing between apple and full board"""
            gd.end_round()
            break
        """Apple placing"""
        for i in range(len(game.get_apple_list())):
            """checks for bad placing"""
            if bool(set(game.get_apple_list()[i].get_location()) & set(coordinates_of_wave)):
                game.get_apple_list()[i] = Apples()
            if bool(set(game.get_apple_list()[i].get_location()) & set(coordinates_of_bomb)):
                game.get_apple_list()[i] = Apples()
            if bool(set(game.get_apple_list()[i].get_location()) & set(apple_list_locations)):
                game.get_apple_list()[i] = Apples()
            if bool(set(game.get_apple_list()[i].get_location()) & set(coordinates_of_snake)):
                game.get_apple_list()[i] = Apples()
        """snake direction"""
        key_clicked = gd.get_key_clicked()
        if key_clicked is not None:
            game.get_snake().set_head_direction(key_clicked)
        """apples"""
        for i in range(len(game.get_apple_list())):
            location = game.get_apple_list()[i].get_location()
            gd.draw_cell(location[0], location[1], "green")
            if game.get_snake().get_snake_head() == location:
                game.add_to_counter(3)
                game.add_to_score(game.get_apple_list()[i].get_score())
                game.get_apple_list()[i] = Apples()
                location = game.get_apple_list()[i].get_location()
                gd.draw_cell(location[0], location[1], "green")

        """move snake"""
        if game.get_snake().is_destination_coordinate_legal(key_clicked):
            game.move_snake(gd, key_clicked)
        else:
            for tpl in coordinates_of_snake[1:]:
                gd.draw_cell(tpl[0], tpl[1], "black")
            if game.get_bomb().did_bomb_explode():
                for wave in coordinates_of_wave:
                    row_wave = wave[1]
                    col_wave = wave[0]
                    gd.draw_cell(col_wave, row_wave, "orange")
            else:
                gd.draw_cell(game.get_bomb().get_bomb_location()[0], game.get_bomb().get_bomb_location()[1], "red")
            gd.end_round()
            break

        """bomb"""
        if not game.get_bomb().did_bomb_explode():
            gd.draw_cell(game.get_bomb().get_bomb_location()[0], game.get_bomb().get_bomb_location()[1], "red")
            game.get_bomb().countdown_to_explosion()
        elif game.get_bomb().did_bomb_explode():
            if game.get_bomb().get_radius() <= game.get_bomb().get_max_radius():
                for wave in game.get_bomb().coordinates_of_wave():
                    row_wave = wave[1]
                    col_wave = wave[0]
                    if wave not in cell_list(game_parameters.WIDTH, game_parameters.HEIGHT):
                        bomb = Bomb()
                        gd.draw_cell(bomb.get_bomb_location()[0], bomb.get_bomb_location()[1], "red")
                        gd.end_round()
                        break
                    else:
                        gd.draw_cell(col_wave, row_wave, "orange")
                game.get_bomb().get_progress_radius()
            else:
                game.change_bomb(Bomb())
        gd.show_score(game.get_score())
        gd.end_round()

